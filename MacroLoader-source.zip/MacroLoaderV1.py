import ctypes
import json
import os
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from ctypes import wintypes

if sys.platform != "win32":
    sys.exit("MacroLoader fonctionne uniquement sous Windows.")

def ensure_admin():
    try:
        if ctypes.windll.shell32.IsUserAnAdmin():
            return
    except Exception:
        return
    if getattr(sys, "frozen", False):
        exe, params = sys.executable, " ".join(f'"{a}"' for a in sys.argv[1:])
    else:
        exe, params = sys.executable, " ".join(f'"{a}"' for a in sys.argv)
    if ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, None, 1) > 32:
        sys.exit(0)

ensure_admin()

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

try:
    ctypes.windll.winmm.timeBeginPeriod(1)
except Exception:
    pass

user32 = ctypes.windll.user32
ULONG_PTR = ctypes.c_size_t

def get_safe_log_path():
    try:
        base_dir = os.environ.get("ProgramFiles", "C:\\Program Files")
        target_dir = os.path.join(base_dir, "MacroLoader")
        os.makedirs(target_dir, exist_ok=True)
        test_path = os.path.join(target_dir, "MacroLoader.log")
        with open(test_path, "a", encoding="utf-8") as f:
            pass
        return test_path
    except Exception:
        appdata_dir = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "MacroLoader")
        os.makedirs(appdata_dir, exist_ok=True)
        return os.path.join(appdata_dir, "MacroLoader.log")

LOG_PATH = get_safe_log_path()

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class _U(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("u", _U)]

MOVE, ABSOLUTE, VIRTUALDESK = 0x1, 0x8000, 0x4000
BTN = {"L": (0x2, 0x4), "R": (0x8, 0x10), "M": (0x20, 0x40)}

def _send(inp):
    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

def _mouse(flags, x=0, y=0):
    i = INPUT(type=0)
    i.u.mi = MOUSEINPUT(x, y, 0, flags, 0, 0)
    _send(i)

def cursor_pos():
    p = wintypes.POINT()
    user32.GetCursorPos(ctypes.byref(p))
    return p.x, p.y

def screen_size():
    return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

def move_to(x, y):
    user32.SetCursorPos(int(x), int(y))
    vx, vy = user32.GetSystemMetrics(76), user32.GetSystemMetrics(77)
    vw, vh = user32.GetSystemMetrics(78), user32.GetSystemMetrics(79)
    nx = ((x - vx) * 65536 + vw - 1) // vw
    ny = ((y - vy) * 65536 + vh - 1) // vh
    _mouse(MOVE | ABSOLUTE | VIRTUALDESK, nx, ny)
    if cursor_pos() != (x, y):
        user32.SetCursorPos(int(x), int(y))

def button(b, down):
    _mouse(BTN[b][0 if down else 1])

def key_event(vk, down):
    i = INPUT(type=1)
    i.u.ki = KEYBDINPUT(vk, user32.MapVirtualKeyW(vk, 0), 0 if down else 2, 0, 0)
    _send(i)

def key_pressed(vk):
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)

NAME_TO_VK = {f"F{i + 1}": 0x70 + i for i in range(24)}
NAME_TO_VK.update({str(i): 0x30 + i for i in range(10)})
NAME_TO_VK.update({chr(65 + i): 0x41 + i for i in range(26)})
NAME_TO_VK.update({f"NUM{i}": 0x60 + i for i in range(10)})
NAME_TO_VK.update({"SPACE": 0x20, "ENTER": 0x0D, "TAB": 0x09, "INSERT": 0x2D, "DELETE": 0x2E,
                    "HOME": 0x24, "END": 0x23, "PAGEUP": 0x21, "PAGEDOWN": 0x22, "ESC": 0x1B,
                    "UP": 0x26, "DOWN": 0x28, "LEFT": 0x25, "RIGHT": 0x27})

def vk_from_name(name):
    return NAME_TO_VK.get(name.strip().upper().replace(" ", ""))

HOVER_MS = 30
HOLD_MS = 50

def parse_macro(macro):
    timeline, t = [], 0.0
    for ev in macro.get("e", macro.get("events", [])):
        kind = str(ev.get("t", ev.get("type", "")))
        low = kind.lower()
        pos = tuple(ev["p"]) if isinstance(ev.get("p"), (list, tuple)) and len(ev["p"]) == 2 else None

        if "si" in ev:
            for s in ev["si"]:
                st = str(s.get("t", "")).lower()
                if st == "delay":
                    t += s.get("ms", 0)
                elif st == "move" and s.get("p"):
                    timeline.append((t, "move", tuple(s["p"])))
        elif low in ("delay", "wait", "sleep"):
            t += ev.get("ms", ev.get("d", 0))
        elif low == "move" and pos:
            timeline.append((t, "move", pos))
        elif kind[:1].upper() in ("L", "R", "M") and low[1:] in ("down", "up"):
            b, down = kind[0].upper(), low.endswith("down")
            if down:
                if pos:
                    timeline.append((t, "move", pos))
                    t += HOVER_MS
                timeline.append((t, "btn", (b, True, pos)))
            else:
                t += HOLD_MS
                timeline.append((t, "btn", (b, False, pos)))
        elif low in ("keydown", "keyup"):
            for k in ("vk", "k", "key", "code"):
                if k in ev:
                    v = ev[k]
                    vk = v if isinstance(v, int) else vk_from_name(str(v).replace("Key", ""))
                    if vk:
                        timeline.append((t, "key", (vk, low == "keydown")))
                    break
    return timeline

def load_file(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)
    if isinstance(data, dict) and isinstance(data.get("m"), list):
        macros = data["m"]
    elif isinstance(data, list):
        macros = data
    else:
        macros = [data]
    for m in macros:
        tl = parse_macro(m)
        if tl:
            return m.get("Title") or os.path.basename(path), tl
    raise ValueError("Aucune action reconnue dans ce fichier.")

def wait_until(target):
    while True:
        r = target - time.perf_counter()
        if r <= 0:
            return
        if r > 0.003:
            time.sleep(0.001)

def play(timeline, stop, log):
    clicks = exact = 0
    start = time.perf_counter()
    for t_ms, action, a in timeline:
        if stop.is_set():
            break
        wait_until(start + t_ms / 1000.0)
        if action == "move":
            move_to(*a)
        elif action == "btn":
            b, down, pos = a
            if down:
                if pos:
                    move_to(*pos)
                    clicks += 1
                    real = cursor_pos()
                    ok = real == tuple(pos)
                    exact += ok
                    log(f"clic {b} demande={pos} reel={real} {'OK' if ok else 'ECART'}")
            button(b, down)
        elif action == "key":
            key_event(*a)
    return clicks, exact

class MacroLoaderApp:
    def __init__(self, root):
        self.root = root
        root.title("MacroLoader")
        root.geometry("290x250")
        root.resizable(False, False)

        self.timeline = []
        self.stop_event = threading.Event()
        self.thread = None
        self.listening = False
        self.prev_down = False
        self.file_var = tk.StringVar(value="No file selected")
        self.key_var = tk.StringVar(value="F9")
        self.status_var = tk.StringVar(value="Status: Stopped.")
        w, h = screen_size()
        self.info_var = tk.StringVar(value=f"Screen: {w}x{h}")

        f1 = ttk.LabelFrame(root, text="1. Select JSON File")
        f1.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Label(f1, textvariable=self.file_var, width=24).pack(side="left", padx=6, pady=6)
        ttk.Button(f1, text="Browse...", command=self.choose_file).pack(side="right", padx=6)

        f2 = ttk.LabelFrame(root, text="2. Configuration")
        f2.pack(fill="x", padx=8, pady=4)
        ttk.Label(f2, text="Activation Key:").pack(side="left", padx=6, pady=8)
        ttk.Entry(f2, textvariable=self.key_var, width=8).pack(side="left")

        ttk.Label(root, textvariable=self.info_var, foreground="gray").pack(anchor="w", padx=12)
        ttk.Label(root, textvariable=self.status_var, font=("Segoe UI", 9, "bold"),
                  wraplength=270).pack(anchor="w", padx=12, pady=(4, 2))
        self.btn = ttk.Button(root, text="Start Listening", command=self.toggle_listening)
        self.btn.pack(fill="x", padx=8, pady=4)

        threading.Thread(target=self.poll_keys, daemon=True).start()

    def log(self, msg):
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(time.strftime("%H:%M:%S ") + msg + "\n")
        except Exception:
            pass

    def choose_file(self):
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json"), ("All Files", "*.*")])
        if not path:
            return
        try:
            _, self.timeline = load_file(path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read macro:\n{e}")
            return
        self.file_var.set(os.path.basename(path))
        pts = [a for _, k, a in self.timeline if k == "move"]
        w, h = screen_size()
        big = [p for p in pts if p[0] >= w or p[1] >= h]
        dur = self.timeline[-1][0] / 1000
        msg = f"{len(self.timeline)} actions, {dur:.1f}s"
        if big:
            msg += f" - WARNING: {len(big)} points out of screen {w}x{h}"
        self.info_var.set(f"Screen: {w}x{h} | {msg}")

    def toggle_listening(self):
        if not self.listening:
            if not self.timeline:
                messagebox.showwarning("MacroLoader", "Please select a JSON file first.")
                return
            if vk_from_name(self.key_var.get()) is None:
                messagebox.showwarning("MacroLoader", "Unknown key. Examples: F9, F6, X, SPACE.")
                return
            self.listening = True
            self.btn.config(text="Stop Listening")
            self.status_var.set(f"Status: Listening... Press '{self.key_var.get().upper()}' to toggle loop.")
        else:
            self.listening = False
            self.stop_event.set()
            self.btn.config(text="Start Listening")
            self.status_var.set("Status: Stopped.")

    def poll_keys(self):
        while True:
            time.sleep(0.01)
            vk = vk_from_name(self.key_var.get())
            down = bool(vk) and key_pressed(vk)
            if down and not self.prev_down and self.listening:
                self.root.after(0, self.trigger)
            self.prev_down = down

    def trigger(self):
        if self.thread and self.thread.is_alive():
            self.stop_event.set()
            self.status_var.set("Status: Stopping loop...")
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self.run_loop, daemon=True)
        self.thread.start()

    def run_loop(self):
        self.log("=== start macro loop ===")
        loop_count = 0
        while not self.stop_event.is_set():
            loop_count += 1
            self.root.after(0, lambda c=loop_count: self.status_var.set(f"Status: Running loop #{c}..."))
            try:
                clicks, exact = play(self.timeline, self.stop_event, self.log)
                if self.stop_event.is_set():
                    break
            except Exception as e:
                self.log(f"ERROR: {e!r}")
                self.root.after(0, lambda err=e: self.status_var.set(f"Status: Error: {err}"))
                break
        self.log("=== stop macro loop ===")
        if self.listening:
            self.root.after(0, lambda: self.status_var.set(f"Status: Listening... Press '{self.key_var.get().upper()}' to toggle loop."))

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

if __name__ == "__main__":
    try:
        root = tk.Tk()
        
        icon_path = resource_path("icon.ico")
        if os.path.exists(icon_path):
            try:
                root.iconbitmap(icon_path)
            except Exception:
                pass

        MacroLoaderApp(root)
        root.mainloop()
    except Exception as e:
        root_err = tk.Tk()
        root_err.withdraw()
        messagebox.showerror("Erreur", f"Une erreur est survenue :\n{e}")
